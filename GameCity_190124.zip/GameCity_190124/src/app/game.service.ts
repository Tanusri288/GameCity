import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from '../../node_modules/rxjs';
import { GameDetails } from './gamedetails';

@Injectable({
  providedIn: 'root'
})
export class GameService {
  game: GameDetails[];
  // tslint:disable-next-line:no-inferrable-types
  cardBalance: number = 600;

  constructor(private http: HttpClient) {
      this.populateGames().subscribe( data => this.game = data, error => console.log(error) );
   }

  populateGames(): Observable<GameDetails[]> {
    return this.http.get<GameDetails[]>('/assets/data/GameList.json');
  }

  getGames(): GameDetails[] {
    return this.game;
  }

  getCardBalance(rate: number): number {
    if (this.cardBalance > rate) {
      this.cardBalance = this.cardBalance - rate;
    }
      return this.cardBalance;
  }
}
